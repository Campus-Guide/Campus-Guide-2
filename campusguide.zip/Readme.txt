The project have a dababase called campus_guide
1. Create this database on your local server
2. The server name is locahost, root and there is no password
3. On the campus_guide database there is one table called users, you have to create this