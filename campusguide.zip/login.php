<?php

require_once('connection.php');

// here we put our sign up creadeantial
if (isset($_POST['btn-save']))
{
	$username = mysqli_real_escape_string($con,$_POST['username']);
	$password = mysqli_real_escape_string($con,$_POST['password']);

	if(empty($username) || empty($password)) {
		echo "Please fill in the blanks";
	}
	else {
		$Pass = md5($password);
		$sql = "insert into users (username,password) values ('$username','$Pass')";
		$result = mysqli_query($con,$sql);
		if ($result) {
			echo "your informations have been saved in the database";
		}
		else {
			echo "Please check your Query";
		}
	}
}
//here we have end
if (isset($_POST['btn-submit']))
{
  if(isset($_POST['username'])) {
    $uname=$_POST['username'];
    $password=$_POST['password'];

    $sql="select * from users where username='".$uname."' AND password='".$password."' limit 1";

    $result=mysqli_query($con,$sql);
    if(mysqli_num_rows($result) == 1) {
      echo"You have successfully logged in!";
      exit();
    }
    else{
      echo"You have entered incorrect password";
      exit();
    }
  }
}

?>


<html>
<head>
<title>Login Form</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="loginbox">
  <img src="avator.png" class="avator">
  <h1 style="color:white">Welcome</h1>
  <form method = "POST" action="#">
    <p>Username</p>
    <input type="text" name="username" placeholder="Username">
    <p>Password</p>
    <input type="password" name="password" placeholder="Password">

    <input type="submit" value="Sign Up" name = "btn-save"/>
    <input type="submit" value="Login" name= "btn-submit">
    <br>
    <a href="">Lost your username/password?</a>
  </form>
</div>
</body>
</html>
